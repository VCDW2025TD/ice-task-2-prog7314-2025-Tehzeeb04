using AndroidX.Biometric;
using AndroidX.Fragment.App;
using Java.Util.Concurrent;
using Android.Security.Keystore;
using Java.Security;
using Javax.Crypto;
using Android.Util;

namespace AndroidAppAPI.Services;

public class BiometricAuthService
{
    private const string KeyName = "MemeStreamBiometricKey";
    private const string KeystoreAlias = "MemeStreamKeystore";
    private readonly FragmentActivity _activity;
    
    public BiometricAuthService(FragmentActivity activity)
    {
        _activity = activity;
    }

    // Events for biometric authentication results
    public event Action<BiometricAuthResult>? AuthenticationResult;
    public event Action<string>? AuthenticationError;

    public bool IsBiometricAvailable()
    {
        return BiometricManager.From(_activity).CanAuthenticate(BiometricManager.Authenticators.BiometricWeak) == BiometricManager.BiometricSuccess;
    }

    public bool IsDeviceSecure()
    {
        var biometricManager = BiometricManager.From(_activity);
        return biometricManager.CanAuthenticate(BiometricManager.Authenticators.BiometricWeak | BiometricManager.Authenticators.DeviceCredential) == BiometricManager.BiometricSuccess;
    }

    public BiometricCapability GetBiometricCapability()
    {
        var biometricManager = BiometricManager.From(_activity);
        var result = biometricManager.CanAuthenticate(BiometricManager.Authenticators.BiometricWeak);

        return result switch
        {
            BiometricManager.BiometricSuccess => BiometricCapability.Available,
            BiometricManager.BiometricErrorNoneEnrolled => BiometricCapability.NotEnrolled,
            BiometricManager.BiometricErrorNoHardware => BiometricCapability.NotAvailable,
            BiometricManager.BiometricErrorHwUnavailable => BiometricCapability.Unavailable,
            _ => BiometricCapability.Unknown
        };
    }

    public async Task<BiometricAuthResult> AuthenticateAsync(string title = "Biometric Authentication", 
                                                           string subtitle = "Use your fingerprint or face to authenticate", 
                                                           string description = "Place your finger on the sensor or look at the camera",
                                                           bool allowDeviceCredentials = true)
    {
        var tcs = new TaskCompletionSource<BiometricAuthResult>();

        try
        {
            // Generate or retrieve the secret key for encryption
            var secretKey = GetOrCreateSecretKey();
            var cipher = GetCipher();
            cipher.Init(CipherMode.EncryptMode, secretKey);

            var biometricPrompt = new BiometricPrompt(_activity as AndroidX.Fragment.App.FragmentActivity, 
                ContextCompat.GetMainExecutor(_activity), 
                new BiometricAuthenticationCallback(tcs));

            var promptInfoBuilder = new BiometricPrompt.PromptInfo.Builder()
                .SetTitle(title)
                .SetSubtitle(subtitle)
                .SetDescription(description);

            if (allowDeviceCredentials)
            {
                promptInfoBuilder.SetAllowedAuthenticators(
                    BiometricManager.Authenticators.BiometricWeak | 
                    BiometricManager.Authenticators.DeviceCredential);
            }
            else
            {
                promptInfoBuilder
                    .SetAllowedAuthenticators(BiometricManager.Authenticators.BiometricWeak)
                    .SetNegativeButtonText("Cancel");
            }

            var promptInfo = promptInfoBuilder.Build();
            var cryptoObject = new BiometricPrompt.CryptoObject(cipher);

            biometricPrompt.Authenticate(promptInfo, cryptoObject);

            return await tcs.Task;
        }
        catch (Exception ex)
        {
            Log.Error("BiometricAuth", $"Authentication error: {ex.Message}");
            return new BiometricAuthResult
            {
                Success = false,
                ErrorMessage = ex.Message,
                ErrorType = BiometricErrorType.Unknown
            };
        }
    }

    public async Task<BiometricAuthResult> AuthenticateForDecryptionAsync(string encryptedData,
                                                                         string title = "Biometric Authentication",
                                                                         string subtitle = "Authenticate to access your account")
    {
        var tcs = new TaskCompletionSource<BiometricAuthResult>();

        try
        {
            var secretKey = GetOrCreateSecretKey();
            var cipher = GetCipher();
            
            // For decryption, we need the IV that was used during encryption
            // This is a simplified example - in production, store IV securely
            var initVector = Convert.FromBase64String(encryptedData.Split(':')[0]);
            var encryptedBytes = Convert.FromBase64String(encryptedData.Split(':')[1]);
            
            var ivSpec = new IvParameterSpec(initVector);
            cipher.Init(CipherMode.DecryptMode, secretKey, ivSpec);

            var biometricPrompt = new BiometricPrompt(_activity as AndroidX.Fragment.App.FragmentActivity,
                ContextCompat.GetMainExecutor(_activity),
                new BiometricDecryptionCallback(tcs, encryptedBytes));

            var promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .SetTitle(title)
                .SetSubtitle(subtitle)
                .SetAllowedAuthenticators(BiometricManager.Authenticators.BiometricWeak)
                .SetNegativeButtonText("Cancel")
                .Build();

            var cryptoObject = new BiometricPrompt.CryptoObject(cipher);
            biometricPrompt.Authenticate(promptInfo, cryptoObject);

            return await tcs.Task;
        }
        catch (Exception ex)
        {
            return new BiometricAuthResult
            {
                Success = false,
                ErrorMessage = ex.Message,
                ErrorType = BiometricErrorType.Unknown
            };
        }
    }

    public string EncryptData(string data, Cipher cipher)
    {
        try
        {
            var encryptedBytes = cipher.DoFinal(System.Text.Encoding.UTF8.GetBytes(data));
            var iv = cipher.GetIV();
            
            // Combine IV and encrypted data
            var ivString = Convert.ToBase64String(iv);
            var encryptedString = Convert.ToBase64String(encryptedBytes);
            
            return $"{ivString}:{encryptedString}";
        }
        catch (Exception ex)
        {
            Log.Error("BiometricAuth", $"Encryption error: {ex.Message}");
            throw;
        }
    }

    private ISecretKey GetOrCreateSecretKey()
    {
        var keyStore = KeyStore.GetInstance("AndroidKeyStore");
        keyStore.Load(null);

        if (keyStore.ContainsAlias(KeyName))
        {
            return keyStore.GetKey(KeyName, null).JavaCast<ISecretKey>();
        }

        var keyGenParameterSpec = new KeyGenParameterSpec.Builder(KeyName, KeyStorePurpose.Encrypt | KeyStorePurpose.Decrypt)
            .SetBlockModes(KeyProperties.BlockModeCbc)
            .SetEncryptionPaddings(KeyProperties.EncryptionPaddingPkcs7)
            .SetUserAuthenticationRequired(true)
            .SetInvalidatedByBiometricEnrollment(true)
            .Build();

        var keyGenerator = KeyGenerator.GetInstance(KeyProperties.KeyAlgorithmAes, "AndroidKeyStore");
        keyGenerator.Init(keyGenParameterSpec);
        
        return keyGenerator.GenerateKey();
    }

    private Cipher GetCipher()
    {
        return Cipher.GetInstance(KeyProperties.KeyAlgorithmAes + "/" + 
                                KeyProperties.BlockModeCbc + "/" + 
                                KeyProperties.EncryptionPaddingPkcs7);
    }

    public void ClearBiometricData()
    {
        try
        {
            var keyStore = KeyStore.GetInstance("AndroidKeyStore");
            keyStore.Load(null);
            keyStore.DeleteEntry(KeyName);
        }
        catch (Exception ex)
        {
            Log.Error("BiometricAuth", $"Error clearing biometric data: {ex.Message}");
        }
    }
}

// Callback for standard biometric authentication
public class BiometricAuthenticationCallback : BiometricPrompt.AuthenticationCallback
{
    private readonly TaskCompletionSource<BiometricAuthResult> _tcs;

    public BiometricAuthenticationCallback(TaskCompletionSource<BiometricAuthResult> tcs)
    {
        _tcs = tcs;
    }

    public override void OnAuthenticationError(int errorCode, Java.Lang.ICharSequence errString)
    {
        base.OnAuthenticationError(errorCode, errString);
        
        var errorType = errorCode switch
        {
            BiometricPrompt.ErrorCanceled => BiometricErrorType.UserCanceled,
            BiometricPrompt.ErrorUserCancel => BiometricErrorType.UserCanceled,
            BiometricPrompt.ErrorLockout => BiometricErrorType.Lockout,
            BiometricPrompt.ErrorLockoutPermanent => BiometricErrorType.PermanentLockout,
            BiometricPrompt.ErrorNoSpace => BiometricErrorType.NoSpace,
            BiometricPrompt.ErrorTimeout => BiometricErrorType.Timeout,
            _ => BiometricErrorType.Unknown
        };

        _tcs.SetResult(new BiometricAuthResult
        {
            Success = false,
            ErrorMessage = errString?.ToString() ?? "Authentication error",
            ErrorType = errorType
        });
    }

    public override void OnAuthenticationFailed()
    {
        base.OnAuthenticationFailed();
        // Don't complete the task here - let user try again
        Log.Debug("BiometricAuth", "Authentication failed - user can retry");
    }

    public override void OnAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result)
    {
        base.OnAuthenticationSucceeded(result);
        
        _tcs.SetResult(new BiometricAuthResult
        {
            Success = true,
            CryptoObject = result.CryptoObject,
            AuthenticationType = result.AuthenticationType switch
            {
                BiometricPrompt.AuthenticationResultTypeDeviceCredential => AuthenticationType.DeviceCredential,
                BiometricPrompt.AuthenticationResultTypeBiometric => AuthenticationType.Biometric,
                _ => AuthenticationType.Unknown
            }
        });
    }
}

// Callback for decryption authentication
public class BiometricDecryptionCallback : BiometricPrompt.AuthenticationCallback
{
    private readonly TaskCompletionSource<BiometricAuthResult> _tcs;
    private readonly byte[] _encryptedData;

    public BiometricDecryptionCallback(TaskCompletionSource<BiometricAuthResult> tcs, byte[] encryptedData)
    {
        _tcs = tcs;
        _encryptedData = encryptedData;
    }

    public override void OnAuthenticationError(int errorCode, Java.Lang.ICharSequence errString)
    {
        base.OnAuthenticationError(errorCode, errString);
        
        _tcs.SetResult(new BiometricAuthResult
        {
            Success = false,
            ErrorMessage = errString?.ToString() ?? "Authentication error"
        });
    }

    public override void OnAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result)
    {
        base.OnAuthenticationSucceeded(result);

        try
        {
            var cipher = result.CryptoObject?.Cipher;
            if (cipher != null)
            {
                var decryptedBytes = cipher.DoFinal(_encryptedData);
                var decryptedData = System.Text.Encoding.UTF8.GetString(decryptedBytes);
                
                _tcs.SetResult(new BiometricAuthResult
                {
                    Success = true,
                    DecryptedData = decryptedData,
                    CryptoObject = result.CryptoObject
                });
            }
            else
            {
                _tcs.SetResult(new BiometricAuthResult
                {
                    Success = false,
                    ErrorMessage = "Cipher not available"
                });
            }
        }
        catch (Exception ex)
        {
            _tcs.SetResult(new BiometricAuthResult
            {
                Success = false,
                ErrorMessage = ex.Message
            });
        }
    }
}

// Data models for biometric authentication
public class BiometricAuthResult
{
    public bool Success { get; set; }
    public string? ErrorMessage { get; set; }
    public BiometricErrorType ErrorType { get; set; }
    public BiometricPrompt.CryptoObject? CryptoObject { get; set; }
    public AuthenticationType AuthenticationType { get; set; }
    public string? DecryptedData { get; set; }
}

public enum BiometricCapability
{
    Available,
    NotAvailable,
    NotEnrolled,
    Unavailable,
    Unknown
}

public enum BiometricErrorType
{
    UserCanceled,
    Lockout,
    PermanentLockout,
    NoSpace,
    Timeout,
    Unknown
}

public enum AuthenticationType
{
    Biometric,
    DeviceCredential,
    Unknown
}

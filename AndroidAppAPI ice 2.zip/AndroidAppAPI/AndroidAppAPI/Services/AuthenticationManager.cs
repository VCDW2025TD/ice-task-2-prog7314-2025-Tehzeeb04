using Android.Content;
using AndroidX.Fragment.App;
using Newtonsoft.Json;

namespace AndroidAppAPI.Services;

public class AuthenticationManager
{
    private readonly FirebaseAuthService _firebaseAuth;
    private readonly BiometricAuthService _biometricAuth;
    private readonly GoogleSignInService _googleSignIn;
    private readonly ISharedPreferences _preferences;
    private const string PREF_BIOMETRIC_ENABLED = "biometric_enabled";
    private const string PREF_ENCRYPTED_CREDENTIALS = "encrypted_credentials";
    private const string PREF_USER_DATA = "user_data";

    public AuthenticationManager(FragmentActivity activity)
    {
        _firebaseAuth = new FirebaseAuthService();
        _biometricAuth = new BiometricAuthService(activity);
        _googleSignIn = new GoogleSignInService(activity);
        _preferences = activity.GetSharedPreferences("MemeStreamAuth", FileCreationMode.Private);

        // Subscribe to authentication events
        _firebaseAuth.AuthStateChanged += OnAuthStateChanged;
        _firebaseAuth.AuthError += OnAuthError;
        _googleSignIn.SignInCompleted += OnGoogleSignInCompleted;
        _googleSignIn.SignInError += OnGoogleSignInError;
        _biometricAuth.AuthenticationResult += OnBiometricAuthResult;
        _biometricAuth.AuthenticationError += OnBiometricAuthError;
    }

    // Events
    public event Action<UserInfo?>? AuthStateChanged;
    public event Action<string>? AuthError;
    public event Action<AuthenticationResult>? AuthenticationCompleted;

    // Properties
    public bool IsUserLoggedIn => _firebaseAuth.IsUserLoggedIn;
    public bool IsBiometricEnabled => _preferences.GetBoolean(PREF_BIOMETRIC_ENABLED, false);
    public bool IsBiometricAvailable => _biometricAuth.IsBiometricAvailable();
    public BiometricCapability BiometricCapability => _biometricAuth.GetBiometricCapability();

    #region Firebase Authentication

    public async Task<AuthenticationResult> SignInWithEmailPasswordAsync(string email, string password, bool enableBiometric = false)
    {
        try
        {
            var result = await _firebaseAuth.SignInWithEmailPasswordAsync(email, password);
            
            if (result.Success && enableBiometric && IsBiometricAvailable)
            {
                await SetupBiometricAuthenticationAsync(email, password);
            }

            return new AuthenticationResult
            {
                Success = result.Success,
                User = result.User,
                Token = result.Token,
                ErrorMessage = result.ErrorMessage,
                AuthMethod = AuthenticationMethod.EmailPassword
            };
        }
        catch (Exception ex)
        {
            return new AuthenticationResult
            {
                Success = false,
                ErrorMessage = ex.Message,
                AuthMethod = AuthenticationMethod.EmailPassword
            };
        }
    }

    public async Task<AuthenticationResult> CreateUserWithEmailPasswordAsync(string email, string password, string displayName, bool enableBiometric = false)
    {
        try
        {
            var result = await _firebaseAuth.CreateUserWithEmailPasswordAsync(email, password, displayName);
            
            if (result.Success && enableBiometric && IsBiometricAvailable)
            {
                await SetupBiometricAuthenticationAsync(email, password);
            }

            return new AuthenticationResult
            {
                Success = result.Success,
                User = result.User,
                Token = result.Token,
                ErrorMessage = result.ErrorMessage,
                AuthMethod = AuthenticationMethod.EmailPassword
            };
        }
        catch (Exception ex)
        {
            return new AuthenticationResult
            {
                Success = false,
                ErrorMessage = ex.Message,
                AuthMethod = AuthenticationMethod.EmailPassword
            };
        }
    }

    public async Task<AuthenticationResult> SignInWithGoogleAsync()
    {
        try
        {
            _googleSignIn.SignIn();
            // Result will be handled in OnGoogleSignInCompleted event
            return new AuthenticationResult
            {
                Success = true,
                AuthMethod = AuthenticationMethod.Google,
                IsPending = true
            };
        }
        catch (Exception ex)
        {
            return new AuthenticationResult
            {
                Success = false,
                ErrorMessage = ex.Message,
                AuthMethod = AuthenticationMethod.Google
            };
        }
    }

    public async Task<AuthenticationResult> SilentGoogleSignInAsync()
    {
        try
        {
            var result = await _googleSignIn.SilentSignInAsync();
            if (result.Success && !string.IsNullOrEmpty(result.IdToken))
            {
                var firebaseResult = await _firebaseAuth.SignInWithGoogleAsync(result.IdToken);
                return new AuthenticationResult
                {
                    Success = firebaseResult.Success,
                    User = firebaseResult.User,
                    Token = firebaseResult.Token,
                    ErrorMessage = firebaseResult.ErrorMessage,
                    AuthMethod = AuthenticationMethod.Google
                };
            }
            
            return new AuthenticationResult
            {
                Success = false,
                ErrorMessage = result.ErrorMessage,
                AuthMethod = AuthenticationMethod.Google
            };
        }
        catch (Exception ex)
        {
            return new AuthenticationResult
            {
                Success = false,
                ErrorMessage = ex.Message,
                AuthMethod = AuthenticationMethod.Google
            };
        }
    }

    #endregion

    #region Biometric Authentication

    public async Task<AuthenticationResult> SignInWithBiometricAsync()
    {
        try
        {
            if (!IsBiometricEnabled)
            {
                return new AuthenticationResult
                {
                    Success = false,
                    ErrorMessage = "Biometric authentication is not enabled",
                    AuthMethod = AuthenticationMethod.Biometric
                };
            }

            var encryptedData = _preferences.GetString(PREF_ENCRYPTED_CREDENTIALS, null);
            if (string.IsNullOrEmpty(encryptedData))
            {
                return new AuthenticationResult
                {
                    Success = false,
                    ErrorMessage = "No stored credentials found",
                    AuthMethod = AuthenticationMethod.Biometric
                };
            }

            var biometricResult = await _biometricAuth.AuthenticateForDecryptionAsync(encryptedData);
            if (biometricResult.Success && !string.IsNullOrEmpty(biometricResult.DecryptedData))
            {
                var credentials = JsonConvert.DeserializeObject<StoredCredentials>(biometricResult.DecryptedData);
                if (credentials != null)
                {
                    var firebaseResult = await _firebaseAuth.SignInWithEmailPasswordAsync(credentials.Email, credentials.Password);
                    return new AuthenticationResult
                    {
                        Success = firebaseResult.Success,
                        User = firebaseResult.User,
                        Token = firebaseResult.Token,
                        ErrorMessage = firebaseResult.ErrorMessage,
                        AuthMethod = AuthenticationMethod.Biometric
                    };
                }
            }

            return new AuthenticationResult
            {
                Success = false,
                ErrorMessage = biometricResult.ErrorMessage ?? "Biometric authentication failed",
                AuthMethod = AuthenticationMethod.Biometric
            };
        }
        catch (Exception ex)
        {
            return new AuthenticationResult
            {
                Success = false,
                ErrorMessage = ex.Message,
                AuthMethod = AuthenticationMethod.Biometric
            };
        }
    }

    private async Task<bool> SetupBiometricAuthenticationAsync(string email, string password)
    {
        try
        {
            var biometricResult = await _biometricAuth.AuthenticateAsync(
                "Setup Biometric Authentication",
                "Authenticate to enable biometric login",
                "This will allow you to sign in using your fingerprint or face"
            );

            if (biometricResult.Success && biometricResult.CryptoObject?.Cipher != null)
            {
                var credentials = new StoredCredentials { Email = email, Password = password };
                var credentialsJson = JsonConvert.SerializeObject(credentials);
                var encryptedData = _biometricAuth.EncryptData(credentialsJson, biometricResult.CryptoObject.Cipher);

                _preferences.Edit()
                    .PutString(PREF_ENCRYPTED_CREDENTIALS, encryptedData)
                    .PutBoolean(PREF_BIOMETRIC_ENABLED, true)
                    .Apply();

                return true;
            }

            return false;
        }
        catch (Exception ex)
        {
            AuthError?.Invoke($"Failed to setup biometric authentication: {ex.Message}");
            return false;
        }
    }

    public void DisableBiometricAuthentication()
    {
        _preferences.Edit()
            .Remove(PREF_ENCRYPTED_CREDENTIALS)
            .PutBoolean(PREF_BIOMETRIC_ENABLED, false)
            .Apply();

        _biometricAuth.ClearBiometricData();
    }

    #endregion

    #region User Management

    public async Task<UserInfo?> GetCurrentUserAsync()
    {
        return await _firebaseAuth.GetCurrentUserInfoAsync();
    }

    public async Task<string?> GetCurrentUserTokenAsync()
    {
        return await _firebaseAuth.GetCurrentUserTokenAsync();
    }

    public async Task<bool> UpdateUserProfileAsync(string displayName, string? photoUrl = null)
    {
        return await _firebaseAuth.UpdateUserProfileAsync(displayName, photoUrl);
    }

    public async Task<bool> SendPasswordResetEmailAsync(string email)
    {
        return await _firebaseAuth.SendPasswordResetEmailAsync(email);
    }

    public async Task<bool> SignOutAsync()
    {
        try
        {
            _firebaseAuth.SignOut();
            await _googleSignIn.SignOutAsync();
            
            // Clear stored user data but keep biometric setting
            _preferences.Edit()
                .Remove(PREF_USER_DATA)
                .Apply();

            return true;
        }
        catch (Exception ex)
        {
            AuthError?.Invoke($"Sign out failed: {ex.Message}");
            return false;
        }
    }

    public async Task<bool> DeleteAccountAsync()
    {
        try
        {
            var result = await _firebaseAuth.DeleteUserAsync();
            if (result)
            {
                DisableBiometricAuthentication();
                await _googleSignIn.RevokeAccessAsync();
                
                _preferences.Edit().Clear().Apply();
            }
            return result;
        }
        catch (Exception ex)
        {
            AuthError?.Invoke($"Account deletion failed: {ex.Message}");
            return false;
        }
    }

    #endregion

    #region Event Handlers

    private void OnAuthStateChanged(UserInfo? user)
    {
        if (user != null)
        {
            // Store user data
            var userJson = JsonConvert.SerializeObject(user);
            _preferences.Edit()
                .PutString(PREF_USER_DATA, userJson)
                .Apply();
        }

        AuthStateChanged?.Invoke(user);
    }

    private void OnAuthError(string error)
    {
        AuthError?.Invoke(error);
    }

    private async void OnGoogleSignInCompleted(GoogleSignInResult result)
    {
        if (result.Success && !string.IsNullOrEmpty(result.IdToken))
        {
            var firebaseResult = await _firebaseAuth.SignInWithGoogleAsync(result.IdToken);
            AuthenticationCompleted?.Invoke(new AuthenticationResult
            {
                Success = firebaseResult.Success,
                User = firebaseResult.User,
                Token = firebaseResult.Token,
                ErrorMessage = firebaseResult.ErrorMessage,
                AuthMethod = AuthenticationMethod.Google
            });
        }
        else
        {
            AuthenticationCompleted?.Invoke(new AuthenticationResult
            {
                Success = false,
                ErrorMessage = result.ErrorMessage,
                AuthMethod = AuthenticationMethod.Google
            });
        }
    }

    private void OnGoogleSignInError(string error)
    {
        AuthError?.Invoke($"Google Sign-In Error: {error}");
    }

    private void OnBiometricAuthResult(BiometricAuthResult result)
    {
        // Handle biometric authentication results if needed
    }

    private void OnBiometricAuthError(string error)
    {
        AuthError?.Invoke($"Biometric Error: {error}");
    }

    #endregion

    #region Activity Result Handling

    public void HandleActivityResult(int requestCode, Result resultCode, Intent? data)
    {
        // Handle Google Sign-In result
        if (requestCode == 9001) // RC_SIGN_IN
        {
            _googleSignIn.HandleSignInResult(data);
        }
    }

    #endregion

    public void Dispose()
    {
        _firebaseAuth?.Dispose();
    }
}

// Data models
public class AuthenticationResult
{
    public bool Success { get; set; }
    public UserInfo? User { get; set; }
    public string? Token { get; set; }
    public string? ErrorMessage { get; set; }
    public AuthenticationMethod AuthMethod { get; set; }
    public bool IsPending { get; set; }
}

public class StoredCredentials
{
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}

public enum AuthenticationMethod
{
    EmailPassword,
    Google,
    Biometric,
    Unknown
}

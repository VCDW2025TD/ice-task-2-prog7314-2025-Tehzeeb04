using Android.Gms.Auth.Api.SignIn;
using Android.Gms.Common.Apis;
using Android.Gms.Tasks;
using Java.Lang;

namespace AndroidAppAPI.Services;

public class GoogleSignInService
{
    private readonly Activity _activity;
    private GoogleSignInClient? _googleSignInClient;
    private const int RC_SIGN_IN = 9001;

    public GoogleSignInService(Activity activity)
    {
        _activity = activity;
        InitializeGoogleSignIn();
    }

    // Events
    public event Action<GoogleSignInResult>? SignInCompleted;
    public event Action<string>? SignInError;

    private void InitializeGoogleSignIn()
    {
        try
        {
            // Configure Google Sign-In
            var gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DefaultSignIn)
                .RequestIdToken("YOUR_WEB_CLIENT_ID_HERE") // Replace with your web client ID from Firebase console
                .RequestEmail()
                .RequestProfile()
                .Build();

            _googleSignInClient = GoogleSignIn.GetClient(_activity, gso);
        }
        catch (Exception ex)
        {
            SignInError?.Invoke($"Failed to initialize Google Sign-In: {ex.Message}");
        }
    }

    public void SignIn()
    {
        try
        {
            if (_googleSignInClient != null)
            {
                var signInIntent = _googleSignInClient.SignInIntent;
                _activity.StartActivityForResult(signInIntent, RC_SIGN_IN);
            }
            else
            {
                SignInError?.Invoke("Google Sign-In client not initialized");
            }
        }
        catch (Exception ex)
        {
            SignInError?.Invoke($"Sign-in failed: {ex.Message}");
        }
    }

    public async Task<GoogleSignInResult> SilentSignInAsync()
    {
        try
        {
            if (_googleSignInClient != null)
            {
                var task = _googleSignInClient.SilentSignIn();
                var result = await task;
                
                if (result != null)
                {
                    return new GoogleSignInResult
                    {
                        Success = true,
                        IdToken = result.IdToken
                    };
                }
            }
            
            return new GoogleSignInResult
            {
                Success = false,
                ErrorMessage = "Silent sign-in failed"
            };
        }
        catch (Exception ex)
        {
            return new GoogleSignInResult
            {
                Success = false,
                ErrorMessage = ex.Message
            };
        }
    }

    public void HandleSignInResult(Intent? data)
    {
        try
        {
            var task = GoogleSignIn.GetSignedInAccountFromIntent(data);
            var account = task.Result?.JavaCast<GoogleSignInAccount>();
            
            if (account != null)
            {
                SignInCompleted?.Invoke(new GoogleSignInResult
                {
                    Success = true,
                    IdToken = account.IdToken,
                    Account = new GoogleAccountInfo
                    {
                        Id = account.Id,
                        Email = account.Email,
                        DisplayName = account.DisplayName,
                        PhotoUrl = account.PhotoUrl?.ToString(),
                        FamilyName = account.FamilyName,
                        GivenName = account.GivenName
                    }
                });
            }
            else
            {
                SignInCompleted?.Invoke(new GoogleSignInResult
                {
                    Success = false,
                    ErrorMessage = "Failed to get account information"
                });
            }
        }
        catch (ApiException ex)
        {
            var errorMessage = ex.StatusCode switch
            {
                GoogleSignInStatusCodes.SignInCancelled => "Sign-in was cancelled",
                GoogleSignInStatusCodes.SignInFailed => "Sign-in failed",
                GoogleSignInStatusCodes.SignInCurrentlyInProgress => "Sign-in is already in progress",
                _ => $"Sign-in failed with code: {ex.StatusCode}"
            };
            
            SignInCompleted?.Invoke(new GoogleSignInResult
            {
                Success = false,
                ErrorMessage = errorMessage
            });
        }
        catch (Exception ex)
        {
            SignInCompleted?.Invoke(new GoogleSignInResult
            {
                Success = false,
                ErrorMessage = ex.Message
            });
        }
    }

    public async Task<bool> SignOutAsync()
    {
        try
        {
            if (_googleSignInClient != null)
            {
                await _googleSignInClient.SignOut();
                return true;
            }
            return false;
        }
        catch (Exception ex)
        {
            SignInError?.Invoke($"Sign-out failed: {ex.Message}");
            return false;
        }
    }

    public async Task<bool> RevokeAccessAsync()
    {
        try
        {
            if (_googleSignInClient != null)
            {
                await _googleSignInClient.RevokeAccess();
                return true;
            }
            return false;
        }
        catch (Exception ex)
        {
            SignInError?.Invoke($"Revoke access failed: {ex.Message}");
            return false;
        }
    }

    public GoogleSignInAccount? GetLastSignedInAccount()
    {
        return GoogleSignIn.GetLastSignedInAccount(_activity);
    }

    public bool IsSignedIn()
    {
        return GetLastSignedInAccount() != null;
    }
}

// Data models
public class GoogleAccountInfo
{
    public string? Id { get; set; }
    public string? Email { get; set; }
    public string? DisplayName { get; set; }
    public string? PhotoUrl { get; set; }
    public string? FamilyName { get; set; }
    public string? GivenName { get; set; }
}

using Firebase.Auth;
using Google.Auth.OAuth2;
using Newtonsoft.Json;
using System.Net.Http.Headers;

namespace AndroidAppAPI.Services;

public class FirebaseAuthService
{
    private readonly FirebaseAuth _auth;
    private readonly HttpClient _httpClient;
    private FirebaseUser? _currentUser;

    public FirebaseAuthService()
    {
        _auth = FirebaseAuth.Instance;
        _httpClient = new HttpClient();
        _currentUser = _auth.CurrentUser;
    }

    // Events for authentication state changes
    public event Action<FirebaseUser?>? AuthStateChanged;
    public event Action<string>? AuthError;

    public FirebaseUser? CurrentUser => _currentUser;
    public bool IsUserLoggedIn => _currentUser != null;

    public async Task<AuthResult> SignInWithGoogleAsync(string idToken)
    {
        try
        {
            var credential = GoogleAuthProvider.GetCredential(idToken, null);
            var authResult = await _auth.SignInWithCredentialAsync(credential);
            
            _currentUser = authResult.User;
            AuthStateChanged?.Invoke(_currentUser);
            
            return new AuthResult
            {
                Success = true,
                User = new UserInfo
                {
                    Uid = authResult.User.Uid,
                    Email = authResult.User.Email,
                    DisplayName = authResult.User.DisplayName,
                    PhotoUrl = authResult.User.PhotoUrl?.ToString()
                },
                Token = await authResult.User.GetIdTokenAsync(false)
            };
        }
        catch (Exception ex)
        {
            AuthError?.Invoke(ex.Message);
            return new AuthResult
            {
                Success = false,
                ErrorMessage = ex.Message
            };
        }
    }

    public async Task<AuthResult> SignInWithEmailPasswordAsync(string email, string password)
    {
        try
        {
            var authResult = await _auth.SignInWithEmailAndPasswordAsync(email, password);
            
            _currentUser = authResult.User;
            AuthStateChanged?.Invoke(_currentUser);
            
            return new AuthResult
            {
                Success = true,
                User = new UserInfo
                {
                    Uid = authResult.User.Uid,
                    Email = authResult.User.Email,
                    DisplayName = authResult.User.DisplayName,
                    PhotoUrl = authResult.User.PhotoUrl?.ToString()
                },
                Token = await authResult.User.GetIdTokenAsync(false)
            };
        }
        catch (Exception ex)
        {
            AuthError?.Invoke(ex.Message);
            return new AuthResult
            {
                Success = false,
                ErrorMessage = ex.Message
            };
        }
    }

    public async Task<AuthResult> CreateUserWithEmailPasswordAsync(string email, string password, string displayName)
    {
        try
        {
            var authResult = await _auth.CreateUserWithEmailAndPasswordAsync(email, password);
            
            // Update user profile with display name
            var profileUpdates = new UserProfileChangeRequest.Builder()
                .SetDisplayName(displayName)
                .Build();
            
            await authResult.User.UpdateProfileAsync(profileUpdates);
            
            _currentUser = authResult.User;
            AuthStateChanged?.Invoke(_currentUser);
            
            return new AuthResult
            {
                Success = true,
                User = new UserInfo
                {
                    Uid = authResult.User.Uid,
                    Email = authResult.User.Email,
                    DisplayName = displayName,
                    PhotoUrl = authResult.User.PhotoUrl?.ToString()
                },
                Token = await authResult.User.GetIdTokenAsync(false)
            };
        }
        catch (Exception ex)
        {
            AuthError?.Invoke(ex.Message);
            return new AuthResult
            {
                Success = false,
                ErrorMessage = ex.Message
            };
        }
    }

    public async Task<string?> GetCurrentUserTokenAsync()
    {
        try
        {
            if (_currentUser != null)
            {
                return await _currentUser.GetIdTokenAsync(false);
            }
            return null;
        }
        catch (Exception ex)
        {
            AuthError?.Invoke(ex.Message);
            return null;
        }
    }

    public async Task<UserInfo?> GetCurrentUserInfoAsync()
    {
        try
        {
            if (_currentUser != null)
            {
                return new UserInfo
                {
                    Uid = _currentUser.Uid,
                    Email = _currentUser.Email,
                    DisplayName = _currentUser.DisplayName,
                    PhotoUrl = _currentUser.PhotoUrl?.ToString()
                };
            }
            return null;
        }
        catch (Exception ex)
        {
            AuthError?.Invoke(ex.Message);
            return null;
        }
    }

    public async Task<bool> UpdateUserProfileAsync(string displayName, string? photoUrl = null)
    {
        try
        {
            if (_currentUser != null)
            {
                var builder = new UserProfileChangeRequest.Builder()
                    .SetDisplayName(displayName);
                
                if (!string.IsNullOrEmpty(photoUrl))
                {
                    builder.SetPhotoUri(Android.Net.Uri.Parse(photoUrl));
                }
                
                var profileUpdates = builder.Build();
                await _currentUser.UpdateProfileAsync(profileUpdates);
                
                AuthStateChanged?.Invoke(_currentUser);
                return true;
            }
            return false;
        }
        catch (Exception ex)
        {
            AuthError?.Invoke(ex.Message);
            return false;
        }
    }

    public async Task<bool> SendPasswordResetEmailAsync(string email)
    {
        try
        {
            await _auth.SendPasswordResetEmailAsync(email);
            return true;
        }
        catch (Exception ex)
        {
            AuthError?.Invoke(ex.Message);
            return false;
        }
    }

    public void SignOut()
    {
        try
        {
            _auth.SignOut();
            _currentUser = null;
            AuthStateChanged?.Invoke(null);
        }
        catch (Exception ex)
        {
            AuthError?.Invoke(ex.Message);
        }
    }

    public async Task<bool> DeleteUserAsync()
    {
        try
        {
            if (_currentUser != null)
            {
                await _currentUser.DeleteAsync();
                _currentUser = null;
                AuthStateChanged?.Invoke(null);
                return true;
            }
            return false;
        }
        catch (Exception ex)
        {
            AuthError?.Invoke(ex.Message);
            return false;
        }
    }

    // Configure HTTP client with authentication token
    public async Task<HttpClient> GetAuthenticatedHttpClientAsync()
    {
        var token = await GetCurrentUserTokenAsync();
        if (!string.IsNullOrEmpty(token))
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
        return _httpClient;
    }

    public void Dispose()
    {
        _httpClient?.Dispose();
    }
}

// Data models for authentication
public class AuthResult
{
    public bool Success { get; set; }
    public UserInfo? User { get; set; }
    public string? Token { get; set; }
    public string? ErrorMessage { get; set; }
}

public class UserInfo
{
    public string Uid { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? DisplayName { get; set; }
    public string? PhotoUrl { get; set; }
    
    [JsonIgnore]
    public string Username => DisplayName ?? Email?.Split('@')[0] ?? "User";
}

// Google Sign-In result model
public class GoogleSignInResult
{
    public bool Success { get; set; }
    public string? IdToken { get; set; }
    public string? ErrorMessage { get; set; }
}

using AndroidX.AppCompat.App;
using AndroidX.RecyclerView.Widget;
using AndroidAppAPI.Services;
using AndroidAppAPI.Activities;
using Google.Android.Material.FloatingActionButton;

namespace AndroidAppAPI;

[Activity(Label = "MemeStream", MainLauncher = false)]
public class MainActivity : AppCompatActivity
{
    private AuthenticationManager? _authManager;
    private RecyclerView? _recyclerView;
    private FloatingActionButton? _fabAddMeme;
    private TextView? _tvWelcome;
    private View? _loadingView;

    protected override void OnCreate(Bundle? savedInstanceState)
    {
        base.OnCreate(savedInstanceState);
        SetContentView(Resource.Layout.activity_main);

        InitializeAuth();
        CheckAuthenticationState();
        InitializeViews();
        SetupEventHandlers();
    }

    private void InitializeAuth()
    {
        _authManager = new AuthenticationManager(this);
        _authManager.AuthStateChanged += OnAuthStateChanged;
    }

    private void CheckAuthenticationState()
    {
        // If user is not logged in, redirect to login
        if (!_authManager!.IsUserLoggedIn)
        {
            RedirectToLogin();
            return;
        }
    }

    private void InitializeViews()
    {
        _recyclerView = FindViewById<RecyclerView>(Resource.Id.recycler_memes);
        _fabAddMeme = FindViewById<FloatingActionButton>(Resource.Id.fab_add_meme);
        _tvWelcome = FindViewById<TextView>(Resource.Id.tv_welcome);
        _loadingView = FindViewById(Resource.Id.loading_view);

        // Setup RecyclerView
        if (_recyclerView != null)
        {
            _recyclerView.SetLayoutManager(new LinearLayoutManager(this));
            // TODO: Set adapter for memes
        }

        // Set welcome message
        UpdateWelcomeMessage();
    }

    private void SetupEventHandlers()
    {
        if (_fabAddMeme != null)
        {
            _fabAddMeme.Click += OnAddMemeClick;
        }
    }

    private async void UpdateWelcomeMessage()
    {
        try
        {
            var user = await _authManager!.GetCurrentUserAsync();
            if (user != null && _tvWelcome != null)
            {
                _tvWelcome.Text = $"Welcome back, {user.Username}!";
            }
        }
        catch (Exception ex)
        {
            // Handle error silently or show message
        }
    }

    private void OnAddMemeClick(object? sender, EventArgs e)
    {
        // TODO: Navigate to add meme activity
        var intent = new Intent(this, typeof(AddMemeActivity));
        StartActivity(intent);
    }

    private void OnAuthStateChanged(UserInfo? user)
    {
        RunOnUiThread(() =>
        {
            if (user == null)
            {
                RedirectToLogin();
            }
            else
            {
                UpdateWelcomeMessage();
            }
        });
    }

    private void RedirectToLogin()
    {
        var intent = new Intent(this, typeof(LoginActivity));
        intent.SetFlags(ActivityFlags.ClearTask | ActivityFlags.NewTask);
        StartActivity(intent);
        Finish();
    }

    public override bool OnCreateOptionsMenu(IMenu? menu)
    {
        MenuInflater.Inflate(Resource.Menu.main_menu, menu);
        return true;
    }

    public override bool OnOptionsItemSelected(IMenuItem item)
    {
        switch (item.ItemId)
        {
            case Resource.Id.action_profile:
                // TODO: Open profile activity
                return true;
            case Resource.Id.action_settings:
                // TODO: Open settings activity
                return true;
            case Resource.Id.action_logout:
                LogoutUser();
                return true;
            default:
                return base.OnOptionsItemSelected(item);
        }
    }

    private async void LogoutUser()
    {
        try
        {
            var success = await _authManager!.SignOutAsync();
            if (success)
            {
                RedirectToLogin();
            }
        }
        catch (Exception ex)
        {
            // Handle logout error
        }
    }

    protected override void OnDestroy()
    {
        _authManager?.Dispose();
        base.OnDestroy();
    }
}
using AndroidX.AppCompat.App;
using AndroidAppAPI.Services;

namespace AndroidAppAPI.Activities;

[Activity(Label = "MemeStream", MainLauncher = true, Theme = "@style/AppTheme.Splash", NoHistory = true)]
public class SplashActivity : AppCompatActivity
{
    protected override void OnCreate(Bundle? savedInstanceState)
    {
        base.OnCreate(savedInstanceState);

        // Initialize and check authentication
        CheckAuthenticationAsync();
    }

    private async void CheckAuthenticationAsync()
    {
        try
        {
            // Add a small delay for splash screen effect
            await Task.Delay(1500);

            var authManager = new AuthenticationManager(this);
            
            // Try silent Google sign-in first
            var silentResult = await authManager.SilentGoogleSignInAsync();
            if (silentResult.Success)
            {
                NavigateToMainActivity();
                return;
            }

            // Check if user is already logged in with Firebase
            if (authManager.IsUserLoggedIn)
            {
                NavigateToMainActivity();
            }
            else
            {
                NavigateToLoginActivity();
            }
        }
        catch (Exception)
        {
            // If there's any error, go to login
            NavigateToLoginActivity();
        }
    }

    private void NavigateToMainActivity()
    {
        var intent = new Intent(this, typeof(MainActivity));
        intent.SetFlags(ActivityFlags.ClearTask | ActivityFlags.NewTask);
        StartActivity(intent);
        Finish();
    }

    private void NavigateToLoginActivity()
    {
        var intent = new Intent(this, typeof(LoginActivity));
        intent.SetFlags(ActivityFlags.ClearTask | ActivityFlags.NewTask);
        StartActivity(intent);
        Finish();
    }
}

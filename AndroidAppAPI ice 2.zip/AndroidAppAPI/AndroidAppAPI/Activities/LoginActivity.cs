using AndroidX.AppCompat.App;
using AndroidX.Fragment.App;
using AndroidAppAPI.Services;
using Google.Android.Material.Button;
using Google.Android.Material.TextInputEditText;
using Google.Android.Material.TextInputLayout;
using AndroidX.Biometric;

namespace AndroidAppAPI.Activities;

[Activity(Label = "MemeStream - Login", Theme = "@style/AppTheme.Login")]
public class LoginActivity : AppCompatActivity
{
    private AuthenticationManager? _authManager;
    private MaterialButton? _btnGoogleSignIn;
    private MaterialButton? _btnEmailSignIn;
    private MaterialButton? _btnCreateAccount;
    private MaterialButton? _btnBiometric;
    private MaterialButton? _btnForgotPassword;
    private TextInputEditText? _etEmail;
    private TextInputEditText? _etPassword;
    private TextInputLayout? _tilEmail;
    private TextInputLayout? _tilPassword;
    private View? _loadingView;
    private TextView? _tvWelcome;
    private ImageView? _ivLogo;

    protected override void OnCreate(Bundle? savedInstanceState)
    {
        base.OnCreate(savedInstanceState);
        SetContentView(Resource.Layout.activity_login);

        InitializeViews();
        InitializeAuth();
        SetupEventHandlers();
        CheckExistingAuth();
    }

    private void InitializeViews()
    {
        _btnGoogleSignIn = FindViewById<MaterialButton>(Resource.Id.btn_google_signin);
        _btnEmailSignIn = FindViewById<MaterialButton>(Resource.Id.btn_email_signin);
        _btnCreateAccount = FindViewById<MaterialButton>(Resource.Id.btn_create_account);
        _btnBiometric = FindViewById<MaterialButton>(Resource.Id.btn_biometric);
        _btnForgotPassword = FindViewById<MaterialButton>(Resource.Id.btn_forgot_password);
        _etEmail = FindViewById<TextInputEditText>(Resource.Id.et_email);
        _etPassword = FindViewById<TextInputEditText>(Resource.Id.et_password);
        _tilEmail = FindViewById<TextInputLayout>(Resource.Id.til_email);
        _tilPassword = FindViewById<TextInputLayout>(Resource.Id.til_password);
        _loadingView = FindViewById(Resource.Id.loading_view);
        _tvWelcome = FindViewById<TextView>(Resource.Id.tv_welcome);
        _ivLogo = FindViewById<ImageView>(Resource.Id.iv_logo);

        // Configure biometric button visibility
        UpdateBiometricButtonVisibility();
    }

    private void InitializeAuth()
    {
        _authManager = new AuthenticationManager(this);
        _authManager.AuthStateChanged += OnAuthStateChanged;
        _authManager.AuthError += OnAuthError;
        _authManager.AuthenticationCompleted += OnAuthenticationCompleted;
    }

    private void SetupEventHandlers()
    {
        if (_btnGoogleSignIn != null)
            _btnGoogleSignIn.Click += OnGoogleSignInClick;

        if (_btnEmailSignIn != null)
            _btnEmailSignIn.Click += OnEmailSignInClick;

        if (_btnCreateAccount != null)
            _btnCreateAccount.Click += OnCreateAccountClick;

        if (_btnBiometric != null)
            _btnBiometric.Click += OnBiometricSignInClick;

        if (_btnForgotPassword != null)
            _btnForgotPassword.Click += OnForgotPasswordClick;

        // Enter key handling for password field
        if (_etPassword != null)
        {
            _etPassword.EditorAction += (sender, e) =>
            {
                if (e.ActionId == Android.Views.InputMethods.ImeAction.Done)
                {
                    OnEmailSignInClick(sender, EventArgs.Empty);
                    e.Handled = true;
                }
            };
        }
    }

    private async void CheckExistingAuth()
    {
        try
        {
            ShowLoading(true);

            // Try silent Google sign-in first
            var silentResult = await _authManager!.SilentGoogleSignInAsync();
            if (silentResult.Success)
            {
                NavigateToMainActivity();
                return;
            }

            // Check if user is already logged in with Firebase
            if (_authManager.IsUserLoggedIn)
            {
                NavigateToMainActivity();
                return;
            }

            ShowLoading(false);
        }
        catch (Exception ex)
        {
            ShowLoading(false);
            ShowError($"Authentication check failed: {ex.Message}");
        }
    }

    private void UpdateBiometricButtonVisibility()
    {
        if (_btnBiometric != null && _authManager != null)
        {
            var capability = _authManager.BiometricCapability;
            var isEnabled = _authManager.IsBiometricEnabled;

            _btnBiometric.Visibility = (capability == BiometricCapability.Available && isEnabled) 
                ? ViewStates.Visible 
                : ViewStates.Gone;

            if (capability == BiometricCapability.Available && isEnabled)
            {
                _btnBiometric.Text = "Sign in with Biometric";
                _btnBiometric.SetIconResource(Resource.Drawable.ic_fingerprint);
            }
        }
    }

    #region Event Handlers

    private async void OnGoogleSignInClick(object? sender, EventArgs e)
    {
        try
        {
            ShowLoading(true);
            ClearErrors();

            var result = await _authManager!.SignInWithGoogleAsync();
            if (!result.Success && !result.IsPending)
            {
                ShowLoading(false);
                ShowError(result.ErrorMessage ?? "Google sign-in failed");
            }
            // Success will be handled in OnAuthenticationCompleted
        }
        catch (Exception ex)
        {
            ShowLoading(false);
            ShowError($"Google sign-in error: {ex.Message}");
        }
    }

    private async void OnEmailSignInClick(object? sender, EventArgs e)
    {
        try
        {
            if (!ValidateEmailPasswordInput())
                return;

            ShowLoading(true);
            ClearErrors();

            var email = _etEmail!.Text!;
            var password = _etPassword!.Text!;
            var enableBiometric = _authManager!.IsBiometricAvailable;

            var result = await _authManager.SignInWithEmailPasswordAsync(email, password, enableBiometric);
            
            ShowLoading(false);
            
            if (result.Success)
            {
                if (enableBiometric)
                {
                    ShowInfo("Biometric authentication has been enabled for future logins");
                }
                NavigateToMainActivity();
            }
            else
            {
                ShowError(result.ErrorMessage ?? "Sign-in failed");
            }
        }
        catch (Exception ex)
        {
            ShowLoading(false);
            ShowError($"Sign-in error: {ex.Message}");
        }
    }

    private void OnCreateAccountClick(object? sender, EventArgs e)
    {
        var intent = new Intent(this, typeof(SignUpActivity));
        StartActivity(intent);
    }

    private async void OnBiometricSignInClick(object? sender, EventArgs e)
    {
        try
        {
            ShowLoading(true);
            ClearErrors();

            var result = await _authManager!.SignInWithBiometricAsync();
            
            ShowLoading(false);
            
            if (result.Success)
            {
                NavigateToMainActivity();
            }
            else
            {
                ShowError(result.ErrorMessage ?? "Biometric authentication failed");
            }
        }
        catch (Exception ex)
        {
            ShowLoading(false);
            ShowError($"Biometric authentication error: {ex.Message}");
        }
    }

    private async void OnForgotPasswordClick(object? sender, EventArgs e)
    {
        try
        {
            var email = _etEmail?.Text?.Trim();
            if (string.IsNullOrEmpty(email))
            {
                _tilEmail!.Error = "Please enter your email address first";
                return;
            }

            ShowLoading(true);
            ClearErrors();

            var success = await _authManager!.SendPasswordResetEmailAsync(email);
            
            ShowLoading(false);
            
            if (success)
            {
                ShowInfo($"Password reset email sent to {email}");
            }
            else
            {
                ShowError("Failed to send password reset email");
            }
        }
        catch (Exception ex)
        {
            ShowLoading(false);
            ShowError($"Password reset error: {ex.Message}");
        }
    }

    #endregion

    #region Authentication Event Handlers

    private void OnAuthStateChanged(UserInfo? user)
    {
        RunOnUiThread(() =>
        {
            if (user != null)
            {
                UpdateBiometricButtonVisibility();
                NavigateToMainActivity();
            }
        });
    }

    private void OnAuthError(string error)
    {
        RunOnUiThread(() =>
        {
            ShowLoading(false);
            ShowError(error);
        });
    }

    private void OnAuthenticationCompleted(AuthenticationResult result)
    {
        RunOnUiThread(() =>
        {
            ShowLoading(false);
            
            if (result.Success)
            {
                NavigateToMainActivity();
            }
            else
            {
                ShowError(result.ErrorMessage ?? "Authentication failed");
            }
        });
    }

    #endregion

    #region Activity Results

    protected override void OnActivityResult(int requestCode, Result resultCode, Intent? data)
    {
        base.OnActivityResult(requestCode, resultCode, data);
        _authManager?.HandleActivityResult(requestCode, resultCode, data);
    }

    #endregion

    #region UI Helper Methods

    private bool ValidateEmailPasswordInput()
    {
        var isValid = true;

        var email = _etEmail?.Text?.Trim();
        var password = _etPassword?.Text;

        if (string.IsNullOrEmpty(email))
        {
            _tilEmail!.Error = "Email is required";
            isValid = false;
        }
        else if (!Android.Util.Patterns.EmailAddress.Matcher(email).Matches())
        {
            _tilEmail!.Error = "Please enter a valid email address";
            isValid = false;
        }
        else
        {
            _tilEmail!.Error = null;
        }

        if (string.IsNullOrEmpty(password))
        {
            _tilPassword!.Error = "Password is required";
            isValid = false;
        }
        else if (password.Length < 6)
        {
            _tilPassword!.Error = "Password must be at least 6 characters";
            isValid = false;
        }
        else
        {
            _tilPassword!.Error = null;
        }

        return isValid;
    }

    private void ClearErrors()
    {
        _tilEmail?.ClearError();
        _tilPassword?.ClearError();
    }

    private void ShowLoading(bool show)
    {
        if (_loadingView != null)
        {
            _loadingView.Visibility = show ? ViewStates.Visible : ViewStates.Gone;
        }

        // Disable buttons during loading
        var isEnabled = !show;
        _btnGoogleSignIn!.Enabled = isEnabled;
        _btnEmailSignIn!.Enabled = isEnabled;
        _btnCreateAccount!.Enabled = isEnabled;
        _btnBiometric!.Enabled = isEnabled;
        _btnForgotPassword!.Enabled = isEnabled;
    }

    private void ShowError(string message)
    {
        var snackbar = Google.Android.Material.Snackbar.Snackbar.Make(
            FindViewById(Android.Resource.Id.Content)!, 
            message, 
            Google.Android.Material.Snackbar.Snackbar.LengthLong);
        
        snackbar.SetBackgroundTint(ContextCompat.GetColor(this, Resource.Color.error_color));
        snackbar.Show();
    }

    private void ShowInfo(string message)
    {
        var snackbar = Google.Android.Material.Snackbar.Snackbar.Make(
            FindViewById(Android.Resource.Id.Content)!, 
            message, 
            Google.Android.Material.Snackbar.Snackbar.LengthLong);
        
        snackbar.SetBackgroundTint(ContextCompat.GetColor(this, Resource.Color.success_color));
        snackbar.Show();
    }

    private void NavigateToMainActivity()
    {
        var intent = new Intent(this, typeof(MainActivity));
        intent.SetFlags(ActivityFlags.ClearTask | ActivityFlags.NewTask);
        StartActivity(intent);
        Finish();
    }

    #endregion

    protected override void OnDestroy()
    {
        _authManager?.Dispose();
        base.OnDestroy();
    }
}

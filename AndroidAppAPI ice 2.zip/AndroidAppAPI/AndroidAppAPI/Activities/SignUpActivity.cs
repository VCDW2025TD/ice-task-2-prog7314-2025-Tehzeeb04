using AndroidX.AppCompat.App;
using AndroidAppAPI.Services;
using Google.Android.Material.Button;
using Google.Android.Material.TextInputEditText;
using Google.Android.Material.TextInputLayout;

namespace AndroidAppAPI.Activities;

[Activity(Label = "MemeStream - Sign Up", Theme = "@style/AppTheme.Login")]
public class SignUpActivity : AppCompatActivity
{
    private AuthenticationManager? _authManager;
    private MaterialButton? _btnGoogleSignUp;
    private MaterialButton? _btnCreateAccount;
    private MaterialButton? _btnBackToLogin;
    private TextInputEditText? _etEmail;
    private TextInputEditText? _etPassword;
    private TextInputEditText? _etConfirmPassword;
    private TextInputEditText? _etDisplayName;
    private TextInputLayout? _tilEmail;
    private TextInputLayout? _tilPassword;
    private TextInputLayout? _tilConfirmPassword;
    private TextInputLayout? _tilDisplayName;
    private View? _loadingView;
    private TextView? _tvTitle;
    private CheckBox? _cbEnableBiometric;

    protected override void OnCreate(Bundle? savedInstanceState)
    {
        base.OnCreate(savedInstanceState);
        SetContentView(Resource.Layout.activity_signup);

        InitializeViews();
        InitializeAuth();
        SetupEventHandlers();
    }

    private void InitializeViews()
    {
        _btnGoogleSignUp = FindViewById<MaterialButton>(Resource.Id.btn_google_signup);
        _btnCreateAccount = FindViewById<MaterialButton>(Resource.Id.btn_create_account);
        _btnBackToLogin = FindViewById<MaterialButton>(Resource.Id.btn_back_to_login);
        _etEmail = FindViewById<TextInputEditText>(Resource.Id.et_email);
        _etPassword = FindViewById<TextInputEditText>(Resource.Id.et_password);
        _etConfirmPassword = FindViewById<TextInputEditText>(Resource.Id.et_confirm_password);
        _etDisplayName = FindViewById<TextInputEditText>(Resource.Id.et_display_name);
        _tilEmail = FindViewById<TextInputLayout>(Resource.Id.til_email);
        _tilPassword = FindViewById<TextInputLayout>(Resource.Id.til_password);
        _tilConfirmPassword = FindViewById<TextInputLayout>(Resource.Id.til_confirm_password);
        _tilDisplayName = FindViewById<TextInputLayout>(Resource.Id.til_display_name);
        _loadingView = FindViewById(Resource.Id.loading_view);
        _tvTitle = FindViewById<TextView>(Resource.Id.tv_title);
        _cbEnableBiometric = FindViewById<CheckBox>(Resource.Id.cb_enable_biometric);

        // Configure biometric checkbox visibility
        UpdateBiometricCheckboxVisibility();
    }

    private void InitializeAuth()
    {
        _authManager = new AuthenticationManager(this);
        _authManager.AuthStateChanged += OnAuthStateChanged;
        _authManager.AuthError += OnAuthError;
        _authManager.AuthenticationCompleted += OnAuthenticationCompleted;
    }

    private void SetupEventHandlers()
    {
        if (_btnGoogleSignUp != null)
            _btnGoogleSignUp.Click += OnGoogleSignUpClick;

        if (_btnCreateAccount != null)
            _btnCreateAccount.Click += OnCreateAccountClick;

        if (_btnBackToLogin != null)
            _btnBackToLogin.Click += OnBackToLoginClick;

        // Enter key handling for confirm password field
        if (_etConfirmPassword != null)
        {
            _etConfirmPassword.EditorAction += (sender, e) =>
            {
                if (e.ActionId == Android.Views.InputMethods.ImeAction.Done)
                {
                    OnCreateAccountClick(sender, EventArgs.Empty);
                    e.Handled = true;
                }
            };
        }
    }

    private void UpdateBiometricCheckboxVisibility()
    {
        if (_cbEnableBiometric != null && _authManager != null)
        {
            var capability = _authManager.BiometricCapability;
            _cbEnableBiometric.Visibility = (capability == BiometricCapability.Available) 
                ? ViewStates.Visible 
                : ViewStates.Gone;

            if (capability == BiometricCapability.Available)
            {
                _cbEnableBiometric.Text = "Enable biometric authentication for future logins";
                _cbEnableBiometric.Checked = true; // Default to enabled
            }
        }
    }

    #region Event Handlers

    private async void OnGoogleSignUpClick(object? sender, EventArgs e)
    {
        try
        {
            ShowLoading(true);
            ClearErrors();

            var result = await _authManager!.SignInWithGoogleAsync();
            if (!result.Success && !result.IsPending)
            {
                ShowLoading(false);
                ShowError(result.ErrorMessage ?? "Google sign-up failed");
            }
            // Success will be handled in OnAuthenticationCompleted
        }
        catch (Exception ex)
        {
            ShowLoading(false);
            ShowError($"Google sign-up error: {ex.Message}");
        }
    }

    private async void OnCreateAccountClick(object? sender, EventArgs e)
    {
        try
        {
            if (!ValidateInput())
                return;

            ShowLoading(true);
            ClearErrors();

            var email = _etEmail!.Text!;
            var password = _etPassword!.Text!;
            var displayName = _etDisplayName!.Text!;
            var enableBiometric = _cbEnableBiometric?.Checked == true && _authManager!.IsBiometricAvailable;

            var result = await _authManager!.CreateUserWithEmailPasswordAsync(email, password, displayName, enableBiometric);
            
            ShowLoading(false);
            
            if (result.Success)
            {
                if (enableBiometric)
                {
                    ShowInfo("Account created successfully! Biometric authentication has been enabled.");
                }
                else
                {
                    ShowInfo("Account created successfully!");
                }
                NavigateToMainActivity();
            }
            else
            {
                ShowError(result.ErrorMessage ?? "Account creation failed");
            }
        }
        catch (Exception ex)
        {
            ShowLoading(false);
            ShowError($"Account creation error: {ex.Message}");
        }
    }

    private void OnBackToLoginClick(object? sender, EventArgs e)
    {
        Finish();
    }

    #endregion

    #region Authentication Event Handlers

    private void OnAuthStateChanged(UserInfo? user)
    {
        RunOnUiThread(() =>
        {
            if (user != null)
            {
                NavigateToMainActivity();
            }
        });
    }

    private void OnAuthError(string error)
    {
        RunOnUiThread(() =>
        {
            ShowLoading(false);
            ShowError(error);
        });
    }

    private void OnAuthenticationCompleted(AuthenticationResult result)
    {
        RunOnUiThread(() =>
        {
            ShowLoading(false);
            
            if (result.Success)
            {
                ShowInfo("Welcome to MemeStream!");
                NavigateToMainActivity();
            }
            else
            {
                ShowError(result.ErrorMessage ?? "Authentication failed");
            }
        });
    }

    #endregion

    #region Activity Results

    protected override void OnActivityResult(int requestCode, Result resultCode, Intent? data)
    {
        base.OnActivityResult(requestCode, resultCode, data);
        _authManager?.HandleActivityResult(requestCode, resultCode, data);
    }

    #endregion

    #region UI Helper Methods

    private bool ValidateInput()
    {
        var isValid = true;

        var email = _etEmail?.Text?.Trim();
        var password = _etPassword?.Text;
        var confirmPassword = _etConfirmPassword?.Text;
        var displayName = _etDisplayName?.Text?.Trim();

        // Validate display name
        if (string.IsNullOrEmpty(displayName))
        {
            _tilDisplayName!.Error = "Display name is required";
            isValid = false;
        }
        else if (displayName.Length < 2)
        {
            _tilDisplayName!.Error = "Display name must be at least 2 characters";
            isValid = false;
        }
        else if (displayName.Length > 30)
        {
            _tilDisplayName!.Error = "Display name must be less than 30 characters";
            isValid = false;
        }
        else
        {
            _tilDisplayName!.Error = null;
        }

        // Validate email
        if (string.IsNullOrEmpty(email))
        {
            _tilEmail!.Error = "Email is required";
            isValid = false;
        }
        else if (!Android.Util.Patterns.EmailAddress.Matcher(email).Matches())
        {
            _tilEmail!.Error = "Please enter a valid email address";
            isValid = false;
        }
        else
        {
            _tilEmail!.Error = null;
        }

        // Validate password
        if (string.IsNullOrEmpty(password))
        {
            _tilPassword!.Error = "Password is required";
            isValid = false;
        }
        else if (password.Length < 8)
        {
            _tilPassword!.Error = "Password must be at least 8 characters";
            isValid = false;
        }
        else if (!HasValidPasswordCharacters(password))
        {
            _tilPassword!.Error = "Password must contain letters and numbers";
            isValid = false;
        }
        else
        {
            _tilPassword!.Error = null;
        }

        // Validate password confirmation
        if (string.IsNullOrEmpty(confirmPassword))
        {
            _tilConfirmPassword!.Error = "Please confirm your password";
            isValid = false;
        }
        else if (password != confirmPassword)
        {
            _tilConfirmPassword!.Error = "Passwords do not match";
            isValid = false;
        }
        else
        {
            _tilConfirmPassword!.Error = null;
        }

        return isValid;
    }

    private bool HasValidPasswordCharacters(string password)
    {
        var hasLetter = false;
        var hasDigit = false;

        foreach (char c in password)
        {
            if (char.IsLetter(c))
                hasLetter = true;
            if (char.IsDigit(c))
                hasDigit = true;
            
            if (hasLetter && hasDigit)
                return true;
        }

        return false;
    }

    private void ClearErrors()
    {
        _tilDisplayName?.ClearError();
        _tilEmail?.ClearError();
        _tilPassword?.ClearError();
        _tilConfirmPassword?.ClearError();
    }

    private void ShowLoading(bool show)
    {
        if (_loadingView != null)
        {
            _loadingView.Visibility = show ? ViewStates.Visible : ViewStates.Gone;
        }

        // Disable buttons during loading
        var isEnabled = !show;
        _btnGoogleSignUp!.Enabled = isEnabled;
        _btnCreateAccount!.Enabled = isEnabled;
        _btnBackToLogin!.Enabled = isEnabled;
    }

    private void ShowError(string message)
    {
        var snackbar = Google.Android.Material.Snackbar.Snackbar.Make(
            FindViewById(Android.Resource.Id.Content)!, 
            message, 
            Google.Android.Material.Snackbar.Snackbar.LengthLong);
        
        snackbar.SetBackgroundTint(ContextCompat.GetColor(this, Resource.Color.error_color));
        snackbar.Show();
    }

    private void ShowInfo(string message)
    {
        var snackbar = Google.Android.Material.Snackbar.Snackbar.Make(
            FindViewById(Android.Resource.Id.Content)!, 
            message, 
            Google.Android.Material.Snackbar.Snackbar.LengthLong);
        
        snackbar.SetBackgroundTint(ContextCompat.GetColor(this, Resource.Color.success_color));
        snackbar.Show();
    }

    private void NavigateToMainActivity()
    {
        var intent = new Intent(this, typeof(MainActivity));
        intent.SetFlags(ActivityFlags.ClearTask | ActivityFlags.NewTask);
        StartActivity(intent);
        Finish();
    }

    #endregion

    protected override void OnDestroy()
    {
        _authManager?.Dispose();
        base.OnDestroy();
    }
}

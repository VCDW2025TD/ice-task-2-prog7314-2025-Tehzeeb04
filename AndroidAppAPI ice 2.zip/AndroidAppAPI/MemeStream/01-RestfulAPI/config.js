// Configuration file for MemeStream API
// Copy this file to .env and update values for production

module.exports = {
  // Server Configuration
  PORT: process.env.PORT || 3000,
  NODE_ENV: process.env.NODE_ENV || 'development',
  
  // MongoDB Configuration
  // For local development: mongodb://localhost:27017/memestream
  // For MongoDB Atlas: mongodb+srv://<username>:<password>@<cluster>.mongodb.net/memestream
  MONGODB_URI: process.env.MONGODB_URI || 'mongodb://localhost:27017/memestream',
  
  // CORS Configuration
  ALLOWED_ORIGINS: process.env.ALLOWED_ORIGINS ? 
    process.env.ALLOWED_ORIGINS.split(',') : 
    ['http://localhost:3000', 'http://localhost:3001', 'http://localhost:8080'],
  
  // API Configuration
  API_VERSION: 'v1',
  MAX_FILE_SIZE: 10485760, // 10MB in bytes
  
  // JWT Secret (if implementing authentication later)
  JWT_SECRET: process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-this-in-production'
};

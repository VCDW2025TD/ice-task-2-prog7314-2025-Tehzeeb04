// Meme Model - MongoDB Schema for meme data
const mongoose = require('mongoose');

const memeSchema = new mongoose.Schema({
  // Basic meme information
  title: {
    type: String,
    required: true,
    trim: true,
    maxlength: 200
  },
  
  description: {
    type: String,
    trim: true,
    maxlength: 1000
  },
  
  // Image/content information
  imageUrl: {
    type: String,
    required: true,
    trim: true
  },
  
  imageType: {
    type: String,
    enum: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
    default: 'image/jpeg'
  },
  
  // User information
  userId: {
    type: String,
    required: true,
    trim: true
  },
  
  username: {
    type: String,
    required: true,
    trim: true,
    maxlength: 50
  },
  
  // Meme metadata
  category: {
    type: String,
    trim: true,
    maxlength: 50,
    default: 'general'
  },
  
  tags: [{
    type: String,
    trim: true,
    maxlength: 30
  }],
  
  // Engagement metrics
  likes: {
    type: Number,
    default: 0,
    min: 0
  },
  
  views: {
    type: Number,
    default: 0,
    min: 0
  },
  
  shares: {
    type: Number,
    default: 0,
    min: 0
  },
  
  // Social features
  likedBy: [{
    userId: String,
    timestamp: {
      type: Date,
      default: Date.now
    }
  }],
  
  comments: [{
    userId: String,
    username: String,
    text: {
      type: String,
      maxlength: 500
    },
    timestamp: {
      type: Date,
      default: Date.now
    }
  }],
  
  // Technical metadata
  isPublic: {
    type: Boolean,
    default: true
  },
  
  isApproved: {
    type: Boolean,
    default: true
  },
  
  reportedBy: [{
    userId: String,
    reason: String,
    timestamp: {
      type: Date,
      default: Date.now
    }
  }],
  
  // Timestamps
  createdAt: {
    type: Date,
    default: Date.now
  },
  
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Update the updatedAt field before saving
memeSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Indexes for better query performance
memeSchema.index({ userId: 1, createdAt: -1 });
memeSchema.index({ category: 1, createdAt: -1 });
memeSchema.index({ tags: 1 });
memeSchema.index({ isPublic: 1, isApproved: 1, createdAt: -1 });

// Virtual for URL-friendly meme ID
memeSchema.virtual('slug').get(function() {
  return this.title.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
});

// Method to increment views
memeSchema.methods.incrementViews = function() {
  this.views += 1;
  return this.save();
};

// Method to add like
memeSchema.methods.addLike = function(userId) {
  const existingLike = this.likedBy.find(like => like.userId === userId);
  if (!existingLike) {
    this.likedBy.push({ userId });
    this.likes += 1;
  }
  return this.save();
};

// Method to remove like
memeSchema.methods.removeLike = function(userId) {
  const likeIndex = this.likedBy.findIndex(like => like.userId === userId);
  if (likeIndex > -1) {
    this.likedBy.splice(likeIndex, 1);
    this.likes = Math.max(0, this.likes - 1);
  }
  return this.save();
};

// Static method to get popular memes
memeSchema.statics.getPopular = function(limit = 10) {
  return this.find({ isPublic: true, isApproved: true })
    .sort({ likes: -1, views: -1, createdAt: -1 })
    .limit(limit);
};

// Static method to get recent memes
memeSchema.statics.getRecent = function(limit = 10) {
  return this.find({ isPublic: true, isApproved: true })
    .sort({ createdAt: -1 })
    .limit(limit);
};

module.exports = mongoose.model('Meme', memeSchema);

// Authentication Middleware for MemeStream API
// Verifies Firebase ID tokens and extracts user information

const admin = require('firebase-admin');

// Initialize Firebase Admin SDK
// In production, use environment variables for the service account key
const serviceAccount = {
  // This should be loaded from environment variables or secure configuration
  // For now, this is a placeholder - you'll need to add your Firebase service account key
  type: "service_account",
  project_id: process.env.FIREBASE_PROJECT_ID || "your-project-id",
  private_key_id: process.env.FIREBASE_PRIVATE_KEY_ID,
  private_key: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
  client_email: process.env.FIREBASE_CLIENT_EMAIL,
  client_id: process.env.FIREBASE_CLIENT_ID,
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs"
};

// Initialize Firebase Admin only if not already initialized
if (!admin.apps.length) {
  try {
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount)
    });
    console.log('✅ Firebase Admin initialized successfully');
  } catch (error) {
    console.error('❌ Firebase Admin initialization failed:', error.message);
    console.log('⚠️  Authentication will be disabled. Set up Firebase service account for production.');
  }
}

// Middleware to verify Firebase ID tokens
const verifyToken = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        error: 'No token provided',
        message: 'Authorization header with Bearer token is required',
        timestamp: new Date().toISOString()
      });
    }

    const idToken = authHeader.split('Bearer ')[1];
    
    if (!admin.apps.length) {
      // If Firebase Admin is not initialized, skip verification in development
      console.warn('⚠️  Firebase Admin not initialized - skipping token verification');
      req.user = {
        uid: 'dev-user',
        email: 'dev@memestream.com',
        name: 'Development User'
      };
      return next();
    }

    // Verify the ID token
    const decodedToken = await admin.auth().verifyIdToken(idToken);
    
    // Add user information to request object
    req.user = {
      uid: decodedToken.uid,
      email: decodedToken.email,
      name: decodedToken.name || decodedToken.email?.split('@')[0],
      picture: decodedToken.picture,
      emailVerified: decodedToken.email_verified,
      provider: decodedToken.firebase.sign_in_provider
    };

    next();
  } catch (error) {
    console.error('Token verification error:', error);
    
    let errorMessage = 'Invalid token';
    let statusCode = 401;
    
    if (error.code === 'auth/id-token-expired') {
      errorMessage = 'Token has expired';
    } else if (error.code === 'auth/id-token-revoked') {
      errorMessage = 'Token has been revoked';
    } else if (error.code === 'auth/invalid-id-token') {
      errorMessage = 'Invalid token format';
    }

    return res.status(statusCode).json({
      error: errorMessage,
      code: error.code || 'auth/unknown-error',
      timestamp: new Date().toISOString()
    });
  }
};

// Optional authentication middleware (doesn't fail if no token)
const optionalAuth = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      req.user = null;
      return next();
    }

    const idToken = authHeader.split('Bearer ')[1];
    
    if (!admin.apps.length) {
      req.user = null;
      return next();
    }

    const decodedToken = await admin.auth().verifyIdToken(idToken);
    req.user = {
      uid: decodedToken.uid,
      email: decodedToken.email,
      name: decodedToken.name || decodedToken.email?.split('@')[0],
      picture: decodedToken.picture,
      emailVerified: decodedToken.email_verified,
      provider: decodedToken.firebase.sign_in_provider
    };

    next();
  } catch (error) {
    // Don't fail on optional auth - just set user to null
    req.user = null;
    next();
  }
};

// Middleware to check if user owns a resource
const checkOwnership = (resourceUserIdField = 'userId') => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        error: 'Authentication required',
        timestamp: new Date().toISOString()
      });
    }

    const resourceUserId = req.body[resourceUserIdField] || req.params[resourceUserIdField];
    
    if (req.user.uid !== resourceUserId) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'You can only access your own resources',
        timestamp: new Date().toISOString()
      });
    }

    next();
  };
};

// Middleware to add user info to request body for creation operations
const addUserInfo = (req, res, next) => {
  if (req.user) {
    req.body.userId = req.user.uid;
    req.body.username = req.user.name || req.user.email?.split('@')[0] || 'Anonymous';
  }
  next();
};

// Utility function to get user info for responses
const getUserInfo = (req) => {
  if (!req.user) return null;
  
  return {
    uid: req.user.uid,
    email: req.user.email,
    name: req.user.name,
    picture: req.user.picture,
    emailVerified: req.user.emailVerified,
    provider: req.user.provider
  };
};

module.exports = {
  verifyToken,
  optionalAuth,
  checkOwnership,
  addUserInfo,
  getUserInfo
};
